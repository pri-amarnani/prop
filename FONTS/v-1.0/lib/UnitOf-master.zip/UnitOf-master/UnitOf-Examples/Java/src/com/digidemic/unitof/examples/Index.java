/**
 * https://github.com/Digidemic/UnitOf
 * (c) 2018 DIGIDEMIC, LLC - All Rights Reserved
 * UnitOf developed by Adam Steinberg of DIGIDEMIC, LLC
 * License: Apache License 2.0
 *
 * ====
 *
 * Copyright 2018 DIGIDEMIC, LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/**
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 */
package com.digidemic.unitof.examples;

import com.digidemic.unitof.UnitOf;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Index {
    private static boolean printSyntaxCode = true;
    private static boolean printCommentsWithSyntax = true;
    private static boolean removeAllEmptyLinesInSyntax = false;
    private static boolean runAndPrintExampleResultsInFile = true;
    
    private static final Options OPTIONS = createOptionsList();
    private static ArrayList<Integer> optionSelectedOrder = new ArrayList();
    private static String hierarchyText = "";
    private static final String EXAMPLES_DIRECTORY = System.getProperty("user.dir") + "/src/com/digidemic/unitof/examples/";
    private static final String INVALID_ID_ENTERED = "Invalid ID entered";
    private static final String SHOW_CURRENT_SETTINGS = "Show current settings";
    
    private static final String FILE_HASHMAP_ONELINER = "Anything_Class/CompileTime/HashMapUnits/OnlyOneLiners.java";
    private static final String FILE_HASHMAP_PREDEFMETHODS = "Anything_Class/CompileTime/HashMapUnits/PredefinedMethods.java";
    private static final String FILE_HASHMAP_PUBUNITS = "Anything_Class/CompileTime/HashMapUnits/PublicUnits.java";
    private static final String FILE_ARRAY_ONELINER = "Anything_Class/CompileTime/ArrayUnits/OnlyOneLiners.java";
    private static final String FILE_ARRAY_ONELINERSHORTER = "Anything_Class/CompileTime/ArrayUnits/OnlyOneLiners_ShorterCode.java";
    private static final String FILE_ARRAY_PREDEFMETHODS = "Anything_Class/CompileTime/ArrayUnits/PredefinedMethods.java";
    private static final String FILE_ARRAY_PUBUNITS = "Anything_Class/CompileTime/ArrayUnits/PublicUnits.java";
    private static final String FILE_ANYTHING_RUNTIME = "Anything_Class/Main_Example_RunTime.java";
    private static final String FILE_DATATYPE_ONELINER = "DataType_Class/Basic_1_Line_Conversions.java";
    private static final String FILE_DATATYPE_TWOSTEP = "DataType_Class/Basic_2_Step_Conversions.java";
    private static final String FILE_DATATYPE_BOOL = "DataType_Class/Boolean_Extended_Syntax.java";
    private static final String FILE_DATATYPE_FRAC = "DataType_Class/Fraction_Extended_Syntax.java";
    private static final String FILE_NUMBASE = "NumericBase_Class/NumericBase_Syntax.java";
    private static final String FILE_EXTENDS = "Inheritance/Extends_All_UnitOf_Measurements.java";
    private static final String FILE_BASIC_SYNTAX = "Basic_Syntax.java";
   
    private static final String INTRO = ""
            + "Welcome to the UnitOf Example Project by Digidemic, LLC!\n" 
            + "Below this body of text is the navigator to run and show the syntax of the example code in this project.\n"
            + "The index class and executable is just a \"glorified\" file viewer for the examples in this project.\n"
            + "Besides being able to run the examples shown, running this example project is not much more effective than to just roam the package finding what you need to learn.\n"
            + "Testing the Unitof Java Example project was all done using Netbeans 8.1 IDE.\n";
    
    public static void main(String[] args) {
        createOptionsList();
        startUpText();
    }
   
    private static String settingsText(){
        return "Current Settings (Toggle by entering negative id at any time):\n" +
            "0 - " + SHOW_CURRENT_SETTINGS + "\n" +
            "-1 - Print File: " + printSyntaxCode + "\n" +
            "-2 -   Print comments with code syntax: " + printCommentsWithSyntax + "\n" +
            "-3 -   Do not include empty lines: " + removeAllEmptyLinesInSyntax + "\n" +
            "-4 - Run and print example results: " + runAndPrintExampleResultsInFile + "\n";
    }
    
    private static Options currentSetOfOptions(){
        Options option = OPTIONS;
        hierarchyText = "Main Menu > ";
        for(int i : optionSelectedOrder){
            option = option.childOptions.get(i);
            hierarchyText += option.name + " > ";
        }
        return option;
    }
    
    private static void enteredInput(String userInput){
        Options currentSetOfOptions = currentSetOfOptions();
        UnitOf.DataType input = new UnitOf.DataType(userInput);
        if(input.toString().toLowerCase().contains("exit")){
            System.exit(0);
        } else if(input.toString().toLowerCase().contains("back")){
            if(optionSelectedOrder.isEmpty()){
                print("Cannot go back further than main menu");
                return;
            }
            optionSelectedOrder.remove(optionSelectedOrder.size() - 1);
        } else if(input.toInt(-999) != -999){
            if(input.toInt() > 0){
                if(!optionIndexExists(currentSetOfOptions, input.toInt(-999))){
                    print(INVALID_ID_ENTERED);
                    return;
                }
                Options selectedOption = currentSetOfOptions.childOptions.get(input.toInt()-1);
                if(selectedOption.filePath != null){//open file
                    readAndPrintFile(selectedOption);
                } else {
                    optionSelectedOrder.add(input.toInt()-1);//new option
                    return;
                }
            } else {
                switch(input.toInt()){
                    case 0: print(settingsText()); break;
                    case -1: printSyntaxCode = !printSyntaxCode; print("Setting toggled, updated settings below"); print(settingsText()); break;
                    case -2: printCommentsWithSyntax = !printCommentsWithSyntax; print("Setting toggled, updated settings below"); print(settingsText()); break;
                    case -3: removeAllEmptyLinesInSyntax = !removeAllEmptyLinesInSyntax; print("Setting toggled, updated settings below"); print(settingsText()); break;
                    case -4: runAndPrintExampleResultsInFile = !runAndPrintExampleResultsInFile; print("Setting toggled, updated settings below"); print(settingsText()); break;
                    default:
                        print(INVALID_ID_ENTERED);
                }
                return;
            }
        } else {
            print(INVALID_ID_ENTERED);
            return;
        }
    }
    
    private static void readAndPrintFile(Options selectedOption){      
        print(hierarchyText + selectedOption.name + ".java");
        String filePath = EXAMPLES_DIRECTORY + selectedOption.filePath;
        print("File Location: " + filePath);
        print("");
        if(printSyntaxCode){
            print(selectedOption.name + " Syntax" + (printCommentsWithSyntax ? " With Comments" : "Without Comments"));
            print("");
            BufferedReader br = null;
            try {
                br = new BufferedReader(new FileReader(filePath));
                try {
                    String line = br.readLine();
                    while (line != null) {
                        line = br.readLine();
                        if(line != null){
                            
                            boolean printLine = true;//is an empty line was intended print it, but dont if a line is now empty because a comment was the line and now missing
                            if(!printCommentsWithSyntax && !line.contains("//-=-=")){                                                       
                                boolean lineHadContent = !line.replaceAll("\\s+","").isEmpty();
                                line = line.split("//")[0]; 
                                printLine = (!(lineHadContent && line.replaceAll("\\s+","").isEmpty()));
                            }
                            if(removeAllEmptyLinesInSyntax){
                                printLine = !line.replaceAll("\\s+","").isEmpty();
                            } 
                            if(printLine){
                                print(line);
                            }
                        }
                    }
                } catch (Exception ex) {
                    Logger.getLogger(Index.class.getName()).log(Level.SEVERE, null, ex);
                } finally {
                    try {
                        br.close();
                    } catch (Exception ex) {
                        Logger.getLogger(Index.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            } catch (Exception ex) {
                Logger.getLogger(Index.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                try {
                    br.close();
                } catch (Exception ex) {
                    Logger.getLogger(Index.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        if(runAndPrintExampleResultsInFile){
            print("-=-=-=-=-=-=-=-=-=-=-=-=-");
            print("Sample executed results below");
            print("-=-=-=-=-=-=-=-=-=-=-=-=-");
            runExample(selectedOption.filePath);
        }
    }
    
    private static boolean optionIndexExists(Options op, int id){
        return id > 0 && op.childOptions.size() >= id;
    }

    private static void startUpText(){
        print(INTRO);
        getUserInput();
    }
    
    private static void getUserInput(){
        Options option = currentSetOfOptions();
        print(hierarchyText);
        print("0: " + SHOW_CURRENT_SETTINGS);
        for(int i = 0; i < option.childOptions.size(); i++){
            print(i+1 + ": " + option.childOptions.get(i).name);
        }
        
        Scanner input = new Scanner(System.in);
        print("ENTER ID (1 - " + option.childOptions.size() + " or BACK / EXIT):");
        enteredInput(input.next());
        print("-=-=-=-=-=-=-=-=-=-=-");
        getUserInput();
    }
    
    private static Options createOptionsList(){
        ArrayList<Options> colComExHashMap = new ArrayList();
        colComExHashMap.add(new Options("One Liner Syntax", FILE_HASHMAP_ONELINER));
        colComExHashMap.add(new Options("Static Methods Syntax", FILE_HASHMAP_PREDEFMETHODS));
        colComExHashMap.add(new Options("Static Variables Syntax", FILE_HASHMAP_PUBUNITS));
        
        ArrayList<Options> colComExArray = new ArrayList();
        colComExArray.add(new Options("One Liner Syntax", FILE_ARRAY_ONELINER));
        colComExArray.add(new Options("One Liner Syntax (Shorter)", FILE_ARRAY_ONELINERSHORTER));
        colComExArray.add(new Options("Static Methods Syntax", FILE_ARRAY_PREDEFMETHODS));
        colComExArray.add(new Options("Static Variables Syntax", FILE_ARRAY_PUBUNITS));
        
        ArrayList<Options> colAnything = new ArrayList();
        colAnything.add(new Options("Main Run-Time Syntax", FILE_ANYTHING_RUNTIME));
        colAnything.add(new Options("Compile-Time Examples Units in HashMap form", colComExHashMap));
        colAnything.add(new Options("Compile-Time Examples Units in Array form", colComExArray));
        
        
        ArrayList<Options> colDataTypeSyntax = new ArrayList();
        colDataTypeSyntax.add(new Options("Basic/Main Syntax (One Liner)", FILE_DATATYPE_ONELINER));
        colDataTypeSyntax.add(new Options("Basic/Main Syntax (Declare then Init)", FILE_DATATYPE_TWOSTEP));
        colDataTypeSyntax.add(new Options("Boolean Extended Syntax", FILE_DATATYPE_BOOL));
        colDataTypeSyntax.add(new Options("Fraction Extended Syntax", FILE_DATATYPE_FRAC));
        
        
        ArrayList<Options> colSpecialClassList = new ArrayList();
        colSpecialClassList.add(new Options("UnitOf.Anything() Examples", colAnything));
        colSpecialClassList.add(new Options("UnitOf.DataType() Examples", colDataTypeSyntax));
        colSpecialClassList.add(new Options("UnitOf.NumericBase() Syntax", FILE_NUMBASE));
        colSpecialClassList.add(new Options("UnitOf Inheritance Syntax", FILE_EXTENDS));
        
        ArrayList<Options> origChoices = new ArrayList();
        origChoices.add(new Options("Basic/Main Syntax", FILE_BASIC_SYNTAX));
        origChoices.add(new Options("Special Class Examples", colSpecialClassList));

        return new Options("Main Menu", origChoices);
    }

    private static void runExample(String filePath){
        switch(filePath){
            case FILE_HASHMAP_ONELINER: com.digidemic.unitof.examples.Anything_Class.CompileTime.HashMapUnits.OnlyOneLiners.runTestExample(); break;
            case FILE_HASHMAP_PREDEFMETHODS: com.digidemic.unitof.examples.Anything_Class.CompileTime.HashMapUnits.PredefinedMethods.runTestExample(); break;
            case FILE_HASHMAP_PUBUNITS: com.digidemic.unitof.examples.Anything_Class.CompileTime.HashMapUnits.PublicUnits.runTestExample(); break;
            case FILE_ARRAY_ONELINER: com.digidemic.unitof.examples.Anything_Class.CompileTime.ArrayUnits.OnlyOneLiners.runTestExample(); break;
            case FILE_ARRAY_ONELINERSHORTER: com.digidemic.unitof.examples.Anything_Class.CompileTime.ArrayUnits.OnlyOneLiners_ShorterCode.runTestExample(); break;
            case FILE_ARRAY_PREDEFMETHODS: com.digidemic.unitof.examples.Anything_Class.CompileTime.ArrayUnits.PredefinedMethods.runTestExample(); break;
            case FILE_ARRAY_PUBUNITS: com.digidemic.unitof.examples.Anything_Class.CompileTime.ArrayUnits.PublicUnits.runTestExample(); break;
            case FILE_ANYTHING_RUNTIME: com.digidemic.unitof.examples.Anything_Class.Main_Example_RunTime.run(); break;
            case FILE_DATATYPE_ONELINER: com.digidemic.unitof.examples.DataType_Class.Basic_1_Line_Conversions.run(); break;
            case FILE_DATATYPE_TWOSTEP: com.digidemic.unitof.examples.DataType_Class.Basic_2_Step_Conversions.run(); break;
            case FILE_DATATYPE_BOOL: 
                com.digidemic.unitof.examples.DataType_Class.Boolean_Extended_Syntax.oneLiner_1_Step(); 
                com.digidemic.unitof.examples.DataType_Class.Boolean_Extended_Syntax.setThenConvert_2_Steps(); 
            break;
            case FILE_DATATYPE_FRAC: com.digidemic.unitof.examples.DataType_Class.Fraction_Extended_Syntax.run(); break;
            case FILE_NUMBASE: 
                com.digidemic.unitof.examples.NumericBase_Class.NumericBase_Syntax.oneLiner_1_Step();
                com.digidemic.unitof.examples.NumericBase_Class.NumericBase_Syntax.setThenConvert_2_Steps();
                com.digidemic.unitof.examples.NumericBase_Class.NumericBase_Syntax.instantiateSetThenConvert_3_Steps();
                com.digidemic.unitof.examples.NumericBase_Class.NumericBase_Syntax.getFromTypeAndValue();
                com.digidemic.unitof.examples.NumericBase_Class.NumericBase_Syntax.illegalArgumentException();
                break;
            case FILE_EXTENDS:
                com.digidemic.unitof.examples.Inheritance.Extends_All_UnitOf_Measurements.oneLiner_1_Step();
                com.digidemic.unitof.examples.Inheritance.Extends_All_UnitOf_Measurements.setThenConvert_2_Steps();
                com.digidemic.unitof.examples.Inheritance.Extends_All_UnitOf_Measurements.instantiateSetThenConvert_3_Steps();
                com.digidemic.unitof.examples.Inheritance.Extends_All_UnitOf_Measurements.getFromTypeAndValue();
                com.digidemic.unitof.examples.Inheritance.Extends_All_UnitOf_Measurements.setThenConvertTwice();
                break;
            case FILE_BASIC_SYNTAX: 
                com.digidemic.unitof.examples.Basic_Syntax.oneLiner_1_Step();
                com.digidemic.unitof.examples.Basic_Syntax.setThenConvert_2_Steps();
                com.digidemic.unitof.examples.Basic_Syntax.instantiateSetThenConvert_3_Steps();
                com.digidemic.unitof.examples.Basic_Syntax.getFromTypeAndValue();
                com.digidemic.unitof.examples.Basic_Syntax.setThenConvertTwice(); 
                break;
            default:
                print("File example to run could not be found.");                
        }
    }

    public static void print(Object obj){
        System.out.println(String.valueOf(obj));
    }
    
    private static class Options{
        public String name = "";
        public String filePath = null;
        public ArrayList<Options> childOptions = new ArrayList();
        
        public Options(){}
        
        public Options(String name, ArrayList<Options> op){
            this.name = name;
            this.childOptions = op;
        }
        
        public Options(String name, String filePath){
            this.name = name;
            this.filePath = filePath;
        }
    }
}

