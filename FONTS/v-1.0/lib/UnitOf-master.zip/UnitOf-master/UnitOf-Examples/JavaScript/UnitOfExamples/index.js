/**
 * https://github.com/Digidemic/UnitOf
 * (c) 2018 DIGIDEMIC, LLC - All Rights Reserved
 * UnitOf developed by Adam Steinberg of DIGIDEMIC, LLC
 * License: Apache License 2.0
 *
 * ====
 *
 * Copyright 2018 DIGIDEMIC, LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 *
 */

var IMPORTANT_MESSAGE = "IMPORTANT: A localhost environment my be needed to properly run/print the selected examples in your browser.<br/> " +
    "Testing the UnitOf JavaScript Example project was all done using JetBrain's WebStorm IDE (Mostly using Google Chrome as the browser).<br/> " +
    "WebStorm does all the heavy lifting in setting up a localhost environment for testing a web project in the browser.";

var INTRO = "Welcome to the UnitOf Example Project by Digidemic, LLC! <br/>" +
    "Below this body of text is the navigator (file structure viewer) to run and show the syntax of the example code in this project. <br/>" +
    "The index class and executable is just a \"glorified\" file viewer for the examples in this project. <br/> " +
    "Besides being able to run the examples shown, running this example project is not much more effective than to just roam the package finding what you need to learn. <br/> " +
    "<br/>" + IMPORTANT_MESSAGE;

document.getElementById("intro").innerHTML = INTRO;
var origin = window.location.origin;

function isChecked(id){
    var elmID = document.getElementById(id);
    elmChecked = true;
    if(elmID != null){
        elmChecked = elmID.checked;
    }
    return elmChecked;
}

function toggleDisplay(id, imgID, isHidden){
    isHidden = isHidden || (document.getElementById(id).style.display == 'none');
    document.getElementById(id).style.display = isHidden ? '' : 'none';
    document.getElementById(imgID).src = isHidden ? 'assets/caret_down.png' : 'assets/caret_right.png';
}

function addBR(txt){
    return txt + "<br />"
}

function fileButtonClick(elm){
    var val = elm.value;
    switch(UnitOf.DataType(val).toInt()){
        case 1: readTextFile(origin,"/UnitOfExamples/examples/","Basic_Syntax.js", basicSyntax); break;
        case 2: readTextFile(origin,"/UnitOfExamples/examples/Anything_Class/","Main_Example_RunTime.js", anythingMainExampleAtRuntime); break;
        case 3: readTextFile(origin,"/UnitOfExamples/examples/Anything_Class/CompileTime/ArrayUnits/","OnlyOneLiners.js", anythingArrayOneLiner); break;
        case 4: readTextFile(origin,"/UnitOfExamples/examples/Anything_Class/CompileTime/ArrayUnits/","PredefinedFunctions.js", anythingArrayPredefinedFunctions); break;
        case 5: readTextFile(origin,"/UnitOfExamples/examples/Anything_Class/CompileTime/ArrayUnits/","PublicUnits.js", anythingArrayPublicUnits); break;
        case 6: readTextFile(origin,"/UnitOfExamples/examples/Anything_Class/CompileTime/ObjectUnits/","OnlyOneLiners.js", anythingObjectOneLiner); break;
        case 7: readTextFile(origin,"/UnitOfExamples/examples/Anything_Class/CompileTime/ObjectUnits/","PredefinedFunctions.js", anythingObjectPredefinedFunctions); break;
        case 8: readTextFile(origin,"/UnitOfExamples/examples/Anything_Class/CompileTime/ObjectUnits/","PublicUnits.js", anythingObjectPublicUnits); break;
        case 9: readTextFile(origin,"/UnitOfExamples/examples/DataType_Class/","Basic_1_Line_Conversions.js", dataTypeOneLiners); break;
        case 10: readTextFile(origin,"/UnitOfExamples/examples/DataType_Class/","Basic_2_Step_Conversions.js", dataTypeTwoSteps); break;
        case 11: readTextFile(origin,"/UnitOfExamples/examples/DataType_Class/","Boolean_Extended_Syntax.js", dataTypeBoolean); break;
        case 12: readTextFile(origin,"/UnitOfExamples/examples/DataType_Class/","Fraction_Extended_Syntax.js", dataTypeFraction); break;
        case 13: readTextFile(origin,"/UnitOfExamples/examples/NumericBase_Class/","NumericBase_Syntax.js", numericBase); break;
        default: console.log("Could not find button value");
    }
}

function sampleButtonPressedToggle(){
    toggleDisplay('allSettings', 'allSettingsImg', false);
    toggleDisplay('allFiles', 'allFilesImg', false);
    toggleDisplay('allResults', 'allResultsImg', true);
}

function readTextFile(origin, hierarchy, fileName, func) {
    var file = origin + hierarchy + fileName;

    var printFileChecked = isChecked('printFile');
    var printCommentsChecked = isChecked('printComments');
    var noEmptyLinesChecked = isChecked('noEmptyLines');
    var runAndPrintExChecked = isChecked('runAndPrintEx');

    var rawFile = new XMLHttpRequest();
    rawFile.open("GET", file, false);
    rawFile.onreadystatechange = function () {
        if(rawFile.readyState === 4) {
            if(rawFile.status === 200 || rawFile.status == 0) {
                sampleButtonPressedToggle();

                var textToDisplay = '';
                var fileDetails = '';
                var fileExecutedResults = '';

                fileDetails += "<b>" + addBR("File Location: " + file) + "</b>";
                document.getElementById("codeSyntaxContainer").style.display = printFileChecked ? '' : 'none';
                if(printFileChecked) {

                    fileDetails += "<b>" + addBR(fileName + " Syntax" + (printCommentsChecked ? " With Comments" : " Without Comments")) + "</b>";
                    var allTextPerLine = rawFile.responseText.split('\n');
                    for (var i = 0; i < allTextPerLine.length; i++) {
                        var line = allTextPerLine[i];
                        var printLine = true;//is an empty line was intended print it, but dont if a line is now empty because a comment was the line and now missing
                        if (!printCommentsChecked && !line.includes("//-=-=")) {
                            var lineHadContent = !line.replace(/\s/g, '').length <= 0;
                            line = line.split("//")[0] + '\n';
                            printLine = (!(lineHadContent && line.replace(/\s/g, '').length <= 0));
                        }
                        if (noEmptyLinesChecked) {
                            printLine = !line.replace(/\s/g, '').length <= 0;
                        }
                        if (printLine) {
                            textToDisplay += line;
                        }
                    }
                }
                if(runAndPrintExChecked){
                    fileExecutedResults += "<b>" + addBR("-=-=-=-=-=-=-=-=-=-=-=-=-") + "</b>";
                    fileExecutedResults += "<b>" + addBR("Sample executed results below") + "</b>";
                    fileExecutedResults += "<b>" + addBR("-=-=-=-=-=-=-=-=-=-=-=-=-") + "</b>";
                    fileExecutedResults += '';
                    fileExecutedResults += func();
                    fileExecutedResults = fileExecutedResults.replace(/\n/g, "<br />");
                }

                document.getElementById("fileDetails").innerHTML = fileDetails;
                document.getElementById("codeSyntax").innerHTML = textToDisplay;
                document.getElementById("fileExecutedResults").innerHTML = fileExecutedResults;
            }
        }
    };

    try {
        rawFile.send(null);
    } catch(e){
        sampleButtonPressedToggle();

        document.getElementById("codeSyntax").innerHTML = "" +
            "<b>FAILED TO RUN AND PRINT EXAMPLE AND CODE.<br/>" +
            "This is probably due to not having a localhost environment setup for this project.</b><br/><br/>" +
            "Below is the exception thrown:<br/>" + e + "<br/><br/> " +
            "<u>The following is copied from the \"UnitOf Intro\" section</u>:<br/> " +
            IMPORTANT_MESSAGE;
    }
}