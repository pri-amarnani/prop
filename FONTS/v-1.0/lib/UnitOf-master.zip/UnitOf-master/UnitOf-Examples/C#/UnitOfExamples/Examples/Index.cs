﻿/**
 * https://github.com/Digidemic/UnitOf
 * (c) 2018 DIGIDEMIC, LLC - All Rights Reserved
 * UnitOf developed by Adam Steinberg of DIGIDEMIC, LLC
 * License: Apache License 2.0
 *
 * ====
 *
 * Copyright 2018 DIGIDEMIC, LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 *
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 * THIS FILE CONTAINS NO UnitOf EXAMPLES, OPEN ANY OTHER FILE IN THE EXAMPLE FOLDER FOR SYNTAX EXAMPLES
 * THESE EXAMPLES WERE MADE SO YOU DO NOT NEED TO RUN ANYTHING HERE.
 * SIMPLY GO DIRECTLY TO THE DESIRED CLASS AND OPEN,COPY/PASE,MODIFY, WHATEVER!
 * THIS INDEX CLASS SPECIFICALLY IS MEANT FOR RUNNING THE EXAMPLES IMMEDIATELY.
 * 
 */

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnitOf;

namespace UnitOfExamples
{
    class Index
    {
        private static bool printSyntaxCode = true;
        private static bool printCommentsWithSyntax = true;
        private static bool removeAllEmptyLinesInSyntax = false;
        private static bool runAndPrintExampleResultsInFile = true;

        private static Options OPTIONS = createOptionsList();
        private static ArrayList optionSelectedOrder = new ArrayList();
        private static string hierarchyText = "";
        private static string EXAMPLES_DIRECTORY = (System.IO.Directory.GetCurrentDirectory()).Split(new string[] { "bin\\Debug", "bin\\Release" }, StringSplitOptions.None)[0] + "Examples\\";
        private const string INVALID_ID_ENTERED = "Invalid ID entered";
        private const string SHOW_CURRENT_SETTINGS = "Show current settings";
        private const string FILE_DICTIONARY_ONELINER = "Anything_Class/CompileTime/DictionaryUnits/OnlyOneLiners.cs";
        private const string FILE_DICTIONARY_PREDEFMETHODS = "Anything_Class/CompileTime/DictionaryUnits/PredefinedMethods.cs";
        private const string FILE_DICTIONARY_PUBUNITS = "Anything_Class/CompileTime/DictionaryUnits/PublicUnits.cs";
        private const string FILE_ARRAY_ONELINER = "Anything_Class/CompileTime/ArrayUnits/OnlyOneLiners.cs";
        private const string FILE_ARRAY_ONELINERSHORTER = "Anything_Class/CompileTime/ArrayUnits/OnlyOneLiners_ShorterCode.cs";
        private const string FILE_ARRAY_PREDEFMETHODS = "Anything_Class/CompileTime/ArrayUnits/PredefinedMethods.cs";
        private const string FILE_ARRAY_PUBUNITS = "Anything_Class/CompileTime/ArrayUnits/PublicUnits.cs";
        private const string FILE_ANYTHING_RUNTIME = "Anything_Class/Main_Example_RunTime.cs";
        private const string FILE_DATATYPE_ONELINER = "DataType_Class/Basic_1_Line_Conversions.cs";
        private const string FILE_DATATYPE_TWOSTEP = "DataType_Class/Basic_2_Step_Conversions.cs";
        private const string FILE_DATATYPE_BOOL = "DataType_Class/Boolean_Extended_Syntax.cs";
        private const string FILE_DATATYPE_FRAC = "DataType_Class/Fraction_Extended_Syntax.cs";
        private const string FILE_BASIC_SYNTAX = "Basic_Syntax.cs";

        private const string INTRO = ""
                + "Welcome to the UnitOf Example Project by Digidemic, LLC!\n" 
                + "Below this body of text is the navigator to run and show the syntax of the example code in this project.\n"
                + "The index class and executable is just a \"glorified\" file viewer for the examples in this project.\n"
                + "Besides being able to run the examples shown, running this example project is not much more effective than to just roam the package finding what you need to learn.\n"
                + "Testing the UnitOf C# Example project was all done using Microsoft Visual Studio 2012.\n";

        static void Main(string[] args){
            createOptionsList();
            startUpText();
        }

        public static void print(object obj){
            Console.WriteLine(obj.ToString());
        }

        public class Options{
            public string name = "";
            public string filePath = null;
            public ArrayList childOptions = new ArrayList();
        
            public Options(){}
        
            public Options(string name, ArrayList op){
                this.name = name;
                this.childOptions = op;
            }
        
            public Options(string name, string filePath){
                this.name = name;
                this.filePath = filePath;
            }
        }

        private static string settingsText(){
            return "" + 
                    "Current Settings (Toggle by entering negative id at any time):\n" +
                "0 - " + SHOW_CURRENT_SETTINGS + "\n" +
                "-1 - Print File: " + printSyntaxCode + "\n" +
                "-2 -   Print comments with code syntax: " + printCommentsWithSyntax + "\n" +
                "-3 -   Do not include empty lines: " + removeAllEmptyLinesInSyntax + "\n" +
                "-4 - Run and print example results: " + runAndPrintExampleResultsInFile + "\n";
        }

        private static Options currentSetOfOptionz(){
            Options option = OPTIONS;
            hierarchyText = "Main Menu > ";
            for (int i = 0; i < optionSelectedOrder.Count; i++)
            {
                option = (Options)option.childOptions[(int)optionSelectedOrder[i]];
                hierarchyText += option.name + " > ";
            }
            return option;
        }

        private static void enteredInput(string userInput){
            Options currentSetOfOptions = currentSetOfOptionz();
            UnitOf.DataType input = new UnitOf.DataType(userInput);
            if(input.ToString().ToLower().Contains("exit")){
                Environment.Exit(0);
            } else if(input.ToString().ToLower().Contains("back")){
                if(optionSelectedOrder.Count == 0){
                    print("Cannot go back further than main menu");
                    return;
                }

                optionSelectedOrder.RemoveAt(optionSelectedOrder.Count - 1);
            } else if(input.ToInt(-999) != -999){
                if(input.ToInt() > 0){
                    if(!optionIndexExists(currentSetOfOptions, input.ToInt(-999))){
                        print(INVALID_ID_ENTERED);
                        return;
                    }
                    Options selectedOption = (Options)currentSetOfOptions.childOptions[(input.ToInt()-1)];
                    if(selectedOption.filePath != null){//open file
                        readAndPrintFile(selectedOption);
                    } else {
                        optionSelectedOrder.Add(input.ToInt()-1);//new option
                        return;
                    }
                } else {
                    switch(input.ToInt()){
                        case 0: print(settingsText()); break;
                        case -1: printSyntaxCode = !printSyntaxCode; print("Setting toggled, updated settings below"); print(settingsText()); break;
                        case -2: printCommentsWithSyntax = !printCommentsWithSyntax; print("Setting toggled, updated settings below"); print(settingsText()); break;
                        case -3: removeAllEmptyLinesInSyntax = !removeAllEmptyLinesInSyntax; print("Setting toggled, updated settings below"); print(settingsText()); break;
                        case -4: runAndPrintExampleResultsInFile = !runAndPrintExampleResultsInFile; print("Setting toggled, updated settings below"); print(settingsText()); break;
                        default:
                            print(INVALID_ID_ENTERED);
                            break;
                    }
                    return;
                }
            } else {
                print(INVALID_ID_ENTERED);
                return;
            }
        }
    
        private static void readAndPrintFile(Options selectedOption){
            print(hierarchyText + selectedOption.name + ".cs");
            string filePath = EXAMPLES_DIRECTORY + selectedOption.filePath;
            print("File Location: " + filePath);
            print("");

                
            if(printSyntaxCode){
                print(selectedOption.name + " Syntax" + (printCommentsWithSyntax ? " With Comments" : " Without Comments"));
                print("");

                try{
                    using (StreamReader sr = File.OpenText(filePath)){
                        string line = String.Empty;
                        while ((line = sr.ReadLine()) != null){
                            bool printLine = true;//is an empty line was intended print it, but dont if a line is now empty because a comment was the line and now missing
                            if (!printCommentsWithSyntax && !line.Contains("//-=-=")){
                                bool lineHadContent = line.Replace("\\s+", "").Length != 0;
                                line = line.Split('/')[0];
                                printLine = ((lineHadContent && line.Replace("\\s+", "").Length != 0));
                            }
                            if (removeAllEmptyLinesInSyntax){
                                printLine = line.Replace("\\s+", "").Length != 0;
                            }
                            if (printLine){
                                print(line);
                            }
                        }
                    }
                }
                catch (Exception e){
                    print(e);
                }
            }
                
            
            if(runAndPrintExampleResultsInFile){
                print("-=-=-=-=-=-=-=-=-=-=-=-=-");
                print("Sample executed results below");
                print("-=-=-=-=-=-=-=-=-=-=-=-=-");
                runExample(selectedOption.filePath);
            }
        }
    
        private static bool optionIndexExists(Options op, int id){
            return id > 0 && op.childOptions.Count >= id;
        }

        private static void startUpText(){
            print(INTRO);
            //print(settingsText());
            getUserInput();
        }
    
        private static void getUserInput(){
            Options option = currentSetOfOptionz();
            print(hierarchyText);
            print("0: " + SHOW_CURRENT_SETTINGS);
            for(int i = 0; i < option.childOptions.Count; i++){
                print(i+1 + ": " + ((Options)(option.childOptions[i])).name);
            }
        
            print("ENTER ID (1 - " + option.childOptions.Count + " or BACK / EXIT):");
            string input = Console.ReadLine();
            enteredInput(input);
            print("-=-=-=-=-=-=-=-=-=-=-");
            getUserInput();
        }
    
        private static Options createOptionsList(){
            ArrayList colComExDictionary = new ArrayList();
            colComExDictionary.Add(new Options("One Liner Syntax", FILE_DICTIONARY_ONELINER));
            colComExDictionary.Add(new Options("Static Methods Syntax", FILE_DICTIONARY_PREDEFMETHODS));
            colComExDictionary.Add(new Options("Static Variables Syntax", FILE_DICTIONARY_PUBUNITS));
        
            ArrayList colComExArray = new ArrayList();
            colComExArray.Add(new Options("One Liner Syntax", FILE_ARRAY_ONELINER));
            colComExArray.Add(new Options("One Liner Syntax (Shorter)", FILE_ARRAY_ONELINERSHORTER));
            colComExArray.Add(new Options("Static Methods Syntax", FILE_ARRAY_PREDEFMETHODS));
            colComExArray.Add(new Options("Static Variables Syntax", FILE_ARRAY_PUBUNITS));
        
            ArrayList colAnything = new ArrayList();
            colAnything.Add(new Options("Main Run-Time Syntax", FILE_ANYTHING_RUNTIME));
            colAnything.Add(new Options("Compile-Time Examples Units in Dictionary form", colComExDictionary));
            colAnything.Add(new Options("Compile-Time Examples Units in Array form", colComExArray));
               
            ArrayList colDataTypeSyntax = new ArrayList();
            colDataTypeSyntax.Add(new Options("Basic/Main Syntax (One Liner)", FILE_DATATYPE_ONELINER));
            colDataTypeSyntax.Add(new Options("Basic/Main Syntax (Declare then Init)", FILE_DATATYPE_TWOSTEP));
            colDataTypeSyntax.Add(new Options("Boolean Extended Syntax", FILE_DATATYPE_BOOL));
            colDataTypeSyntax.Add(new Options("Fraction Extended Syntax", FILE_DATATYPE_FRAC));
          
            ArrayList colSpecialClassList = new ArrayList();
            colSpecialClassList.Add(new Options("UnitOf.Anything() Examples", colAnything));
            colSpecialClassList.Add(new Options("UnitOf.DataType() Examples", colDataTypeSyntax));
       
            ArrayList origChoices = new ArrayList();
            origChoices.Add(new Options("Basic/Main Syntax", FILE_BASIC_SYNTAX));
            origChoices.Add(new Options("Special Class Examples", colSpecialClassList));

            return new Options("Main Menu", origChoices);
        }

        private static void runExample(string filePath){
            switch(filePath){
                case FILE_DICTIONARY_ONELINER: UnitOfExamples.Examples.Anything_Class.CompileTime.DictionaryUnits.OnlyOneLiners.runTestExample(); break;
                case FILE_DICTIONARY_PREDEFMETHODS: UnitOfExamples.Examples.Anything_Class.CompileTime.DictionaryUnits.PredefinedMethods.runTestExample(); break;
                case FILE_DICTIONARY_PUBUNITS: UnitOfExamples.Examples.Anything_Class.CompileTime.DictionaryUnits.PublicUnits.runTestExample(); break;
                case FILE_ARRAY_ONELINER: UnitOfExamples.Examples.Anything_Class.CompileTime.ArrayUnits.OnlyOneLiners.runTestExample(); break;
                case FILE_ARRAY_ONELINERSHORTER: UnitOfExamples.Examples.Anything_Class.CompileTime.ArrayUnits.OnlyOneLiners_ShorterCode.runTestExample(); break;
                case FILE_ARRAY_PREDEFMETHODS: UnitOfExamples.Examples.Anything_Class.CompileTime.ArrayUnits.PredefinedMethods.runTestExample(); break;
                case FILE_ARRAY_PUBUNITS: UnitOfExamples.Examples.Anything_Class.CompileTime.ArrayUnits.PublicUnits.runTestExample(); break;
                case FILE_ANYTHING_RUNTIME: UnitOfExamples.Examples.Anything_Class.Main_Example_RunTime.run(); break;
                case FILE_DATATYPE_ONELINER: UnitOfExamples.Examples.DataType_Class.Basic_1_Line_Conversions.run(); break;
                case FILE_DATATYPE_TWOSTEP: UnitOfExamples.Examples.DataType_Class.Basic_2_Step_Conversions.run(); break;
                case FILE_DATATYPE_BOOL:
                    UnitOfExamples.Examples.DataType_Class.Boolean_Extended_Syntax.oneLiner_1_Step();
                    UnitOfExamples.Examples.DataType_Class.Boolean_Extended_Syntax.setThenConvert_2_Steps(); 
                break;
                case FILE_DATATYPE_FRAC: UnitOfExamples.Examples.DataType_Class.Fraction_Extended_Syntax.run(); break;
                case FILE_BASIC_SYNTAX: UnitOfExamples.Basic_Syntax.oneLiner_1_Step();
                    UnitOfExamples.Basic_Syntax.setThenConvert_2_Steps();
                    UnitOfExamples.Basic_Syntax.instantiateSetThenConvert_3_Steps();
                    UnitOfExamples.Basic_Syntax.getFromTypeAndValue();
                    UnitOfExamples.Basic_Syntax.setThenConvertTwice(); 
                    break;
                default:
                    print("File example to run could not be found.");
                    break;
            }
        }
    }
}
