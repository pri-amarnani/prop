app.factory('UOUnitOfIs', function() {
    return [
        'A measurement and programming data type conversion library',
        'Fast in execution, small in size, simple to use, and serializable',
        'For Java, JavaScript, and C#',
        'As little as 64kb for the full 22 measurement suite',
        'No math knowledge needed, all formulas are built-in',
        'Parse any programming data type with UnitOf.DataType',
        'Create your own measurements with UnitOf.Anything',
        'Turn decimals into fractions, fractions into decimals, or simplify fractions',
        'Free and open-source',
        'Simply convert anything into everything'
    ]
});