app.factory('UODoc', function() {
    return [
        { uo: 'DataStorage', text: 'Data Storage' },
        { uo: 'DataTransferRate', text: 'Data Transfer Rate' },
        { uo: 'DataType', text: 'Data Type' },
        { uo: 'ElectricCharge', text: 'Electric Charge' },
        { uo: 'FuelEconomy', text: 'Fuel Economy' },
        { uo: 'MetricPrefix', text: 'Metric Prefix' },
        { uo: 'NumericBase', text: 'Numeric Base' }
    ]
});