﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values To modify the information
// associated with an assembly.
[assembly: AssemblyTitle("UnitOf")]
[assembly: AssemblyDescription("By Adam Steinberg of Digidemic")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("DIGIDEMIC, LLC")]
[assembly: AssemblyProduct("UnitOf")]
[assembly: AssemblyCopyright("Copyright ©  2018 DIGIDEMIC, LLC")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible To false makes the types in this assembly not visible 
// To COM components.  If you need To access a type in this assembly From 
// COM, set the ComVisible attribute To true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed To COM
[assembly: Guid("be7d3d31-9f2d-4e96-989f-8bd01163b8ba")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
